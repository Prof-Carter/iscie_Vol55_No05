% lyapunov_eps_mosek.m
% last modified: 2023/05/20 by Masakatsu KAWATA
% 安定解析問題

clear
format compact
% --- ステップ 1 ---------
A = [ 0  1                                          % システム行列 A の定義：安定
     -2 -3 ];
% --- ステップ 2 ---------
P = sdpvar(2,2,'sy');                               % 決定変数 P：2×2 の対称行列
% --- ステップ 3 ---------
LMI = [];                                           % LMI の記述の初期化
M = P*A + A'*P;                                     % リアプノフ不等式の左辺 M を定義
ep = 1e-7;                                          % 十分小さな正数
LMI = [LMI, M <= - ep*eye(2)];                      % 等号付きに修正：M ≦ -ep*I (< 0)
LMI = [LMI, P >= ep*eye(2)];                        % 等号付きに修正：P ≧  ep*I (> 0)
LMI = [LMI, trace(P) == 1];                         % 等式制約：trace(P) = 1
% --- ステップ 4 ---------
opt = sdpsettings; opt.solver = 'mosek';            % ソルバとして MOSEK を利用
sol = optimize(LMI,[],opt)                          % LMI の求解（凸可解問題）
%%% もしくは上 2 行の代わりに
%%% sol = optimize(LMI,[],sdpsettings('solver','mosek')) 
% ------------------------
disp(' ')
if sol.problem ~= 1                                 % problem = 1 でなければ
    % --- ステップ 5 -------
    if sign(eig(value(-M))) == 1 & ...              % -M の固有値の符号をチェック：すべて 1 なら -M は正定 (M < 0)
       sign(eig(value(P))) == 1                     %  P の固有値の符号をチェック：すべて 1 なら  P は正定 (P > 0)
        disp('***** Feasible! *****')               % 解が得られたことを表示
        P_feas = value(P)                           % 得られたリアプノフ行列 P を表示
    else
        disp('***** Infeasible! *****')             % 解が得られなかったことを表示
    end
else
    disp('***** Infeasible! *****')                 % 解が得られなかったことを表示
end