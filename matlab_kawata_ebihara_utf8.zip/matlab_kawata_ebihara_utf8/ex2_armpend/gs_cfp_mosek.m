% gs_cfp_mosek.m
% last modified: 2023/05/22 by Masakatsu KAWATA
% 凸可解問題 <=== 凸最適化問題で得られた gamma_opt より少し大きな値を用いて解く
% （アーム型倒立振子のゲインスケジューリング制御）

clear
format compact
% ---------------------------
adip                                                    % M ファイル adip.m の実行
% ---------------------------
q1 = 5;                                                 % q1 > 0 の設定
q2 = 1;                                                 % q2 > 0 の設定
q3 = 0.01;                                              % q3 > 0 の設定
q4 = 0.01;                                              % q4 > 0 の設定
R  = 1;                                                 % R > 0 の設定
Qh = diag([sqrt(q1) sqrt(q2) sqrt(q3) sqrt(q4)]);
Q = Qh'*Qh;                                             % Q = Qh'*Qh
% ---------------------------
th1_max  = 60*pi/180;                                   % |theta1(t)| の上限値
th10_max = 50*pi/180;                                   % |theta1(0)| の上限値
drho_max = 1.4;                                         % |(d/dt)rho(t)| の上限値
rho_max  = 1 - cos(th1_max);                            % |rho(t)| の上限値：rho(t) = 1 - cos(theta1(t))
rho0_max = 1 - cos(th10_max);                           % |rho(0)| の上限値
% ---------------------------
n = 4;                                                  % x(t) の次元
p = 1;                                                  % u(t) の次元
X_0 = sdpvar(n,n,'sy');                                 % 決定変数 X_0：n×n の対称行列
X_1 = sdpvar(n,n,'sy');                                 % 決定変数 X_1：n×n の対称行列
F_0 = sdpvar(p,n,'f');                                  % 決定変数 F_0：p×n の長方行列
F_1 = sdpvar(p,n,'f');                                  % 決定変数 F_1：p×n の長方行列
gamma = 194;                                            % gamma
% ---------------------------
eps = 1e-7;                                             % 十分小さな正数
% ---------------------------
LMI = [];                                               % LMI の記述の初期化
% ---------------------------
rho = [0 1]*rho_max;                                    % rho の変動の端点

for i = 1:2
    X  = X_0 + rho(i)*X_1;                              % 端点における X = X_0 + rho*X_1
    M1 = X;                                             % 変動の端点における M1
    LMI = [LMI, M1 >= eps*eye(length(M1))];             % 等号付き LMI で表現：M1 ≧ eps*I (> 0)
end
% ---------------------------
rho1 = [0 1 0 1]*rho_max;                               % (rho,rho^2) の変動を囲む凸多面体（直方体）T の頂点
rho2 = [0 0 1 1]*rho_max^2;
drho = [-1 1]*drho_max;                                 % (d/dt)rho の変動の端点

Phi_0 = A_0*X_0 + B_0*F_0;                              % Phi(rho) = A(rho)*X(rho) + B(rho)*F(rho) の 0 次項
Phi_1 = A_1*X_0 + B_1*F_0 ...
      + A_0*X_1 + B_0*F_1;                              % Phi(rho) = A(rho)*X(rho) + B(rho)*F(rho) の 1 次項
Phi_2 = A_1*X_1 + B_1*F_1;                              % Phi(rho) = A(rho)*X(rho) + B(rho)*F(rho) の 2 次項

for i = 1:4
    for j = 1:2
        Phi = Phi_0 + rho1(i)*Phi_1 + rho2(i)*Phi_2;    % 凸多面体（直方体）T の頂点における Phi(rho)
    
        X  = X_0 + rho1(i)*X_1;                         % 凸多面体（直方体）T の頂点における X(rho)
        F  = F_0 + rho1(i)*F_1;                         % 凸多面体（直方体）T の頂点における F(rho)
        dX = drho(j)*X_1;                               % (d/dt)rho の変動の端点における dX(rho)/dt

        M2 = [-(Phi+Phi'-dX)   X*Qh        F'*R
                   Qh*X       eye(n)    zeros(n,p)
                    R*F      zeros(p,n)     R     ];    % 変動の端点（あるいは凸多面体の頂点）における M2
        LMI = [LMI, M2 >= eps*eye(length(M2))];         % 等号付き LMI で表現：M2 ≧ eps*I (> 0)
    end
end
% ---------------------------
rho0 = [0 1]*rho0_max;                                  % rho(0) の変動の端点

for i = 1:2
    X_rho0  = X_0 + rho0(i)*X_1;

    M3 = [ gamma*eye(n)  eye(n)
              eye(n)     X_rho0 ];
    LMI = [LMI, M3 >= eps*eye(length(M3))];             % 等号付き LMI で表現：M3 ≧ eps*I (> 0)
end
% ---------------------------
opt = sdpsettings; opt.solver = 'mosek';                % ソルバとして MOSEK を利用
sol = optimize(LMI,[],opt)                              % LMI の求解（凸可解問題）
%%% もしくは上 2 行の代わりに
%%% sol = optimize(LMI,[],sdpsettings('solver','mosek')) 
% ---------------------------
if sol.problem ~= 1                                     % problem = 1 でなければ
    format short e
    pres       = check(LMI)                             % 等号付き LMI M ≧ eps*I (> 0) における M - eps*I の最小固有値
    pres_exact = pres + eps                             % M の最小固有値
    format short
    disp(' ')
    
    if pres_exact > 0                                   % M の最小固有値がすべて正ならば
        disp('***** Feasible! *****')                   % 解が得られたことを表示
        gamma                                           % gamma を表示
        X_0_opt = value(X_0)                            % 得られた X_0 を表示
        X_1_opt = value(X_1)                            % 得られた X_1 を表示
        F_0_opt = value(F_0)                            % 得られた F_0 を表示
        F_1_opt = value(F_1)                            % 得られた F_1 を表示
    else                                                % M の最小固有値に負のものが含まれるならば
        disp('***** Infeasible! *****')                 % 解が得られなかったことを表示
    end
end
