% plot_gs_R2018a.m
% last modified: 2023/05/22 by Masakatsu KAWATA
% GS 制御の非線形シミュレーション
close all

gs_sedumi
% gs_cfp_sedumi

% ------------------------------------------------
K_LQ = - lqr(A_0,B_0,Q,R)

% ------------------------------------------------
for num = 10:10:50
    theta1_0 = num*pi/180;

    sim('GS_LQ_R2018a')
    figure(1); plot(t,theta1/num,'LineWidth',1.5); hold on
    figure(2); plot(t,theta1_LQ/num,'LineWidth',1.5); hold on

    figure(3); plot(t,theta2/num,'LineWidth',1.5); hold on
    figure(4); plot(t,theta2_LQ/num,'LineWidth',1.5); hold on

    figure(5); plot(t,u/num,'LineWidth',1.5); hold on
    figure(6); plot(t,u_LQ/num,'LineWidth',1.5); hold on
end

for i = [1 2]
    figure(i); hold off
    xlim([0 3])
    ylim([-0.6 1.35])
    set(gca,'XTick',0:0.5:3)
    set(gca,'YTick',-0.5:0.25:1.5)
    set(gca,'FontName','Arial','FontSize',18)
    xlabel('$t$ [s]','Interpreter','latex','FontSize',20)
    ylabel('${\theta}_{1}(t)/{\theta}_{1}(0)$','Interpreter','latex','FontSize',20)
    grid on
end

for i = [3 4]
    figure(i); hold off;
    xlim([0 3])
    ylim([-0.17 0.22])
    set(gca,'XTick',0:0.5:3)
    set(gca,'YTick',[-0.15:0.05:0.2])
    set(gca,'FontName','Arial','FontSize',18)
    xlabel('$t$ [s]','Interpreter','latex','FontSize',20)
    ylabel('${\theta}_{2}(t)/{\theta}_{1}(0)$','Interpreter','latex','FontSize',20)
    grid on
end

for i = [5 6]
    figure(i); hold off;
    xlim([0 3])
    ylim([-0.11 0.05])
    set(gca,'XTick',0:0.5:3)
    set(gca,'YTick',[-0.1:0.02:0.05])
    set(gca,'FontName','Arial','FontSize',18)
    xlabel('$t$ [s]','Interpreter','latex','FontSize',20)
    ylabel('$v(t)/{\theta}_{1}(0)$','Interpreter','latex','FontSize',20)
    grid on
end

for i = [1 3 5]
    figure(i)
    title('Gain scheduling control','FontName','Arial','FontSize',18)
end

for i = [2 4 6]
    figure(i)
    title('LQ control','FontName','Arial','FontSize',18)
end

for i = 1:4
    figure(i)
    legend({'${\theta}_{1}(0)=10$ [deg]',...
            '${\theta}_{1}(0)=20$ [deg]',...
            '${\theta}_{1}(0)=30$ [deg]',...
            '${\theta}_{1}(0)=40$ [deg]',...
            '${\theta}_{1}(0)=50$ [deg]'})
    set(legend,'Interpreter','latex','FontSize',16)
end

for i = 5:6
    figure(i)
    legend({'${\theta}_{1}(0)=10$ [deg]',...
            '${\theta}_{1}(0)=20$ [deg]',...
            '${\theta}_{1}(0)=30$ [deg]',...
            '${\theta}_{1}(0)=40$ [deg]',...
            '${\theta}_{1}(0)=50$ [deg]'})
    set(legend,'Interpreter','latex','FontSize',16,'Location','SouthEast')
end

figure(1); movegui('northwest')
figure(2); movegui('southwest')
figure(3); movegui('north')
figure(4); movegui('south')
figure(5); movegui('northeast')
figure(6); movegui('southeast')
