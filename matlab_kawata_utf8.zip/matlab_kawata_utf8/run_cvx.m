close all
clear
format compact

sample_cvx_default
% sample_cvx_sedumi
% sample_cvx_sdpt3

K_opt = K;
gamma_opt = gamma;

sample_analysis