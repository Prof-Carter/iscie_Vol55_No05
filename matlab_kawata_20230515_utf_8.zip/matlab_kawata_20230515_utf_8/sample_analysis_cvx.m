K_opt = K;
gamma_opt = gamma;

sample_analysis