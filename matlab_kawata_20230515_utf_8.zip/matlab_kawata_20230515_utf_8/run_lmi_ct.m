close all
clear
format compact

sample_lmi_ct

sample_analysis