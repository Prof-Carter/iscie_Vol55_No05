close all

sample_yalmip_default
% sample_yalmip_sedumi
% sample_yalmip_sdpt3
% sample_yalmip_mosek
% sample_yalmip_lmilab

sample_analysis